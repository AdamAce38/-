library(testthat)
library(AzureKusto)

test_check('AzureKusto')
