# reexport functions from dplyr to satisfy R CMD check

#' @export
dplyr::filter

#' @export
dplyr::intersect

#' @export
dplyr::setdiff

#' @export
dplyr::setequal

#' @export
dplyr::union
