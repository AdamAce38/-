predict.bbase.os <-
function(object, newx) {
	B <- predict(object, newx = newx)
	B
}
