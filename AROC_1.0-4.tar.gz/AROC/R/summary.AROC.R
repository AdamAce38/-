summary.AROC <-
function(object, ...) {
	class(object) <- c(class(object),"summary.AROC")
	object	   	   	
}
