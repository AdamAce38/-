print.summary.AROC <-
function(x,...) {
	print.AROC(x)
	invisible(x)
}
