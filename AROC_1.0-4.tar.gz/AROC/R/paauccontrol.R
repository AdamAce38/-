paauccontrol <-
function(compute = FALSE, value = 1)
	list(compute = compute, value = value)
