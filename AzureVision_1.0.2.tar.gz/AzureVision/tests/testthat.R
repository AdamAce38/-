library(testthat)
library(AzureVision)

test_check("AzureVision")
