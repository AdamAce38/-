plot <- function(x,y,...) {
    UseMethod("plot")
}
