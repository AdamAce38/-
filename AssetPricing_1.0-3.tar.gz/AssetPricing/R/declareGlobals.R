if(getRversion() >= "2.15.1")
    utils::globalVariables(c("gpr","dS","alpha","epsilon",
                             "stabilize","type","lambda","x"))
