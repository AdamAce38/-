/*
 *  AntMAN Package
 *
 */


#ifndef SRC_PRIORS_HPP_
#define SRC_PRIORS_HPP_


#include "PriorDirac.h"
#include "PriorNegativeBinomial.h"
#include "PriorPoisson.h"



#endif /* SRC_PRIORS_HPP_ */
