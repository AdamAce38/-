/*
 *  AntMAN Package
 *
 */


#ifndef SRC_MIXTURES_HPP_
#define SRC_MIXTURES_HPP_

#include "MixtureMultivariateBinomial.h"
#include "MixtureMultiVariateNormal.h"
#include "MixtureUnivariateNormal.h"
#include "MixtureUnivariatePoisson.h"

#endif /* SRC_MIXTURES_HPP_ */
