library(testthat)
library(AustralianPoliticians)

test_check("AustralianPoliticians")
