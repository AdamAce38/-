utils::globalVariables(c("member", "uniqueID", "mpFrom", "mpTo", "senator",
                         "senatorFrom", "senatorTo"))
