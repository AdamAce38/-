# AWR.Kinesis 1.7.6 (2023-08-18)

Main tenace release to update to author/maintainer email addresses.

* Update Amazon Kinesis Client patch version (not updating to more recent to be able to use the AWR package version already on CRAN, and for the purpose of using the MultiLanguageDaemon, it's good enough)
* Document how the bundled jar files were built
* Switch from futile.logger to logger

# AWR.Kinesis 1.7.4 (~2016)

Initial release on CRAN.
