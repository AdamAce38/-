[![CRAN_Status_Badge](http://www.r-pkg.org/badges/version/ArCo)](https://CRAN.R-project.org/package=ArCo) [![downloads](http://cranlogs.r-pkg.org/badges/grand-total/ArCo)](https://CRAN.R-project.org/package=ArCo) 


# R Package ArCo
Set of functions to analyse and estimate Artificial Counterfactual models
# Functions

- fitArCo
- estimate_t0
- plot.fitArCo

