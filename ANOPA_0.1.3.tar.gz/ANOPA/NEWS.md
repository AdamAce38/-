# ANOPA 0.1.3 (March 2023)

* removed some cats and a few `

# ANOPA 0.1.2 (March 2023)

* added \donttest{} to speed tests;

* moved difference-adjustments within the CI.Atrans function.

# ANOPA 0.1.1 (March 2023)

* Beta release of ANOPA on CRAN.

# ANOPA 0.1.0 (January 2023)

* Beta release of ANOPA on GitHub.

