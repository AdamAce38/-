library(testthat)
test_check("ANOPA")