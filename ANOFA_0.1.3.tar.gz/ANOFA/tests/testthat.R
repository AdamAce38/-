library(testthat)
test_check("ANOFA")