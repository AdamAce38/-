# ANOFA 0.1.2 (November 2023)

* Minor changes to the DESCRIPTION file

# ANOFA 0.1.1 (November 2023)

* Beta release of ANOFA on GitHub

