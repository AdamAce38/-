library(testthat)
library(ARUtools)

test_check("ARUtools")
