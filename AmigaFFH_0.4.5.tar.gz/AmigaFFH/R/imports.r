#' @importFrom graphics plot
#' @importFrom grDevices adjustcolor as.raster col2rgb hsv gray rgb rgb2hsv
#' @importFrom methods as new
#' @importFrom stats ave kmeans
#' @importFrom tuneR play MCnames Wave WaveMC
NULL