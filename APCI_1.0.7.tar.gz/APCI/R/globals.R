utils::globalVariables(c("group_id",
                         "cohort_average",
                         "cohort_group",
                         "star",
                         "age_group",
                         "age_estimate",
                         "period_group",
                         "period_estimate",
                         "value",
                         "temp6",
                         "gee",
                         "acc",
                         "pcc",
                         "cohort",
                         "crange",
                         "ccc",
                         "pnorm",
                         "glm",
                         "."))
# . age_estimate age_group as_tibble cohort_average cohort_group
# coord_flip element_blank geom_abline geom_line geom_path geom_point
# geom_text ggplot group_by group_id labs period_estimate period_group
# star summarise temp6 theme_bw theme_void value ylim

