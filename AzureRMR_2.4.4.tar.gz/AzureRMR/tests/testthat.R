library(testthat)
library(AzureRMR)

test_check("AzureRMR")
