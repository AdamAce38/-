library(testthat)
library(AssetAllocation)

test_check("AssetAllocation")
