# AMCP
AMCP contains all of the data sets used in Maxwell, Delaney, & Kelley's (2018) Designing experiments and analyzing data: A model comparison perspective (3rd edition). Information about the book is available at http://www.DesigningExperiments.com. There are no functions in this package. 
