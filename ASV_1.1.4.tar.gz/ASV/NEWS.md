# ASV 1.1.4

- The bug in computing the posterior density is fixed. 

# ASV 1.1.2

- The bug in computing the posterior density is fixed. 

# ASV 1.1.1

- The function type is modified for 'abs' (arma::abs for vector, and fabs for double)  

---
# ASV 1.1.0

- The logarithm of the marginal likelihood is computed using Chib and Jeliazkov (2001)

---

# ASV 1.0.0

- The MCMC estimation package for the stochastic volatility models with and without leverage.

