library(testthat)
library(AzureKeyVault)

test_check("AzureKeyVault")
