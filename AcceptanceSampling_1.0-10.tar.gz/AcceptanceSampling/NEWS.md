# AcceptanceSampling 1.0-10

* Added a `NEWS.md` file to track changes to the package.
* Bug fix to address multi-stage sampling checks of acceptance and rejection numbers.