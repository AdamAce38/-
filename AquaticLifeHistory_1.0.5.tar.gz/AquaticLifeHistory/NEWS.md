# AquaticLifeHistory 1.0.5

* Initial CRAN submission.
