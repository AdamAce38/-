scriptLocation <-
  function()
    system.file("chapters", package = "AppliedPredictiveModeling")
