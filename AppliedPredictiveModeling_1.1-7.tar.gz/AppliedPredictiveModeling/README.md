# AppliedPredictiveModeling
Data and code from Applied Predictive Modeling (2013)
