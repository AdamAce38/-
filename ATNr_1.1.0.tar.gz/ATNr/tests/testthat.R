library(testthat)
library(ATNr)

test_check("ATNr")
