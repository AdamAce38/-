library(testthat)
library(ATbounds)

test_check("ATbounds")
