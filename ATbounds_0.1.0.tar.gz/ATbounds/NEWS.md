# ATbounds 0.1.0 (2021-11-23)
* The first version is is submitted to CRAN.
* Check ([Lee and Weidner, 2021](https://arxiv.org/abs/2111.05243)) for details.
