Based on the individual files in the folder 'individual_images',
the final svg hexagon was created with the open-source program Inkscape.
Just open the 'hex-sticker.svg' file with Inkscape to edit it.
