library(testthat)
library(APCtools)

test_check("APCtools")
