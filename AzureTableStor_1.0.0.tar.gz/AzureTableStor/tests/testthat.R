library(testthat)
library(AzureTableStor)

test_check("AzureTableStor")
