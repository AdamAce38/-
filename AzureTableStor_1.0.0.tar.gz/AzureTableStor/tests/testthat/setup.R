make_name <- function(n=20)
{
    paste0(sample(letters, n, TRUE), collapse="")
}
