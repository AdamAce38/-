#' Example dam genotypes
#'
#' @format A matrix with 14 rows (one row = one dam) and 100 columns (one column = one marker)
"APIS_dam"
