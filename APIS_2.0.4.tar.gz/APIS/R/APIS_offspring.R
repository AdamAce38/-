#' Example offspring genotypes
#'
#' @format A matrix with 500 rows (one row = one offspring) and 100 columns (one column = one marker)
"APIS_offspring"
