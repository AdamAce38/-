#' Example sire genotypes
#'
#' @format A matrix with 39 rows (one row = one sire) and 100 columns (one column = one marker)
"APIS_sire"
