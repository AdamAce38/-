#' Example offspring 3n genotypes
#'
#' @format A matrix with 50 rows (one row = one offspring) and 100 columns (one column = one marker)
"APIS_offspring3n"
