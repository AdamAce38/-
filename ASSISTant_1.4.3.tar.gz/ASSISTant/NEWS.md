# ASSISTant 1.4-3

- Allowing for different control probabilities for discrete Rankin
  scores.

# ASSISTant 1.4-2

- Added Rankin Score vignette
- Generated pkgdown docs

# ASSISTant 1.4-1	
- Fixed typo in `setBoundaries()`
- Updated discrete Rankin score parts

# ASSISTant 1.4

- Wilcoxon fix for Discrete Data
- Added discrete data simulation capability

# ASSISTant 1.3

- Fixed up boundary calculation bugs
- Added computation of stage statistics
- Added confidence intervals per Ka Wai Tsang

# ASSISTant 1.2-2

- First CRAN submission

# ASSISTant 1.2

- Added power calculations
- Added more vignettes 
- Fixed typos

# ASSISTant 1.0

- Initial package for testing

