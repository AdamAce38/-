# ASGS.foyer
CRAN-valid entry for the ASGS package. Use this to install the main ASGS package

```r
library(ASGS.foyer)
install_ASGS()
```
