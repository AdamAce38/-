library(testthat)
library(ASGS.foyer)

test_check("ASGS.foyer")
