#' State shapefile

"STE_2016_simple"
