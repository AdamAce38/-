#' @keywords internal
#' @noRd

is.negative <- function(x) {
  x < 0
}
