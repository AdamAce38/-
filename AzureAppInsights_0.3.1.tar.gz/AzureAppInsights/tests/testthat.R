library(testthat)
library(AzureAppInsights)

local_edition(3)

test_check("AzureAppInsights")
