# AutoPlots 1.0.0
Initial version 

100% data.table backend for fast data processing

Chart types:

Histogram Plots
Density Plots
Box Plots
Probability Plots
Word Cloud
Pie Charts
Donut Plot
Rosetype Plot
Bar Plots
3D Bar Plots
Stacked Bar Plots
Radar Plots
Line Plots
Step Plots
Area Plots
River Plots
Autocorrelation Plot
Partial Autocorrelation Plot
Scatter Plots
3D Scatter Plots
Copula Plots
3D Copula Plots
Correlation Matrix Plots
Parallel Plots
Heatmaps
Calibration Plots
Calibration Scatter Plots
Partital Dependence Plots
Partital Dependence Heatmaps
Variable Importance Plots
Shapely Importance Plots
ROC Plots
Confusion Matrix Heatmaps
Lift Plots
Gain Plots
BinaryMetrics
