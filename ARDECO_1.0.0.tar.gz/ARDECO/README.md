# ardeco-be-rpackage

## Description


## Name
ARDECO - R package

## Description
The code to produce R package to access data from ARDECO  

## Installation
The code could be deployed into own machine and install as a package in R o RStudio. The binary version of this package is also available on CRAN repository.

## Authors and acknowledgment
Show your appreciation to those who have contributed to the project.

## Project status
The project currently provide simple functions to access ARDECO data. New functions are planned to to filter data permitting to download just the data subset of interest.
