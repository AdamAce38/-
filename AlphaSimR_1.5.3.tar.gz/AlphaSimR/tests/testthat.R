library(testthat)
library(AlphaSimR)

test_check("AlphaSimR")
