kpmfe.fun <-
function(Vec, ...)  UseMethod("kpmfe.fun")
