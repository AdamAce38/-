hcvd.fun <-
function(Vec, ...)  UseMethod("hcvd.fun")
