kern.fun <-
function(x,...) UseMethod("kern.fun")
