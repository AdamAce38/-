plot.reg.fun <-
function(x,...) plot.reg.fun1d (x,...)
