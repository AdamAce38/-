plot.hcvc.fun <-
function(x,...) plot.hcvc.fun1d (x,...)
