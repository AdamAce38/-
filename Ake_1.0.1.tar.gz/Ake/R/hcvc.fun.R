hcvc.fun <-
function(Vec, ...)  UseMethod("hcvc.fun")
