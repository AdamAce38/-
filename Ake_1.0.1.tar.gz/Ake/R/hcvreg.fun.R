hcvreg.fun <-
function(Vec, ...)  UseMethod("hcvreg.fun")
