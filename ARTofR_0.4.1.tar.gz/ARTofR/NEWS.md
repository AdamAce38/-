
# ARTofR 0.1.0

* Hzhang 01/09/2021 
* The package used to work by auto-read a txt file, now has been changed into auto-read clipboard


# ARTofR 0.2.2

* Hzhang 01/10/2021 
* Remove dependency of stringr pacakge by writing a simple fold_it function in the package.
* First submission to CRAN.

# ARTofR 0.2.3

* Better instruction!
* Now xxx_box will try to eliminate empty row, keep only one space between paragraph
* Correct xxx_divider that produces lines with different length


# ARTofR 0.3.3

* fix the title2 and title 1 centre problem, now they are perfectly centered
* add xxx_title0 new style

# ARTofR 0.4.1

* Add user interface, to easily apply functions
