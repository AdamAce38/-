#' @keywords internal
#' @md
#' @name AgroR-package
#' @docType package
"_PACKAGE"
