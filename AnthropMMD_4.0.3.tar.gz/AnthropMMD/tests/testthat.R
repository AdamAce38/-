library(testthat)
library(AnthropMMD)

test_check("AnthropMMD")
