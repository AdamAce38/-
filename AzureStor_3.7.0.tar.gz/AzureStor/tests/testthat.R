library(testthat)
library(AzureStor)

test_check("AzureStor")
