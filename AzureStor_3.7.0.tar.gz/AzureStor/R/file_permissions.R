dir_default_perms <- list(
    `x-ms-file-permission`="inherit",
    `x-ms-file-creation-time`="now",
    `x-ms-file-last-write-time`="now",
    `x-ms-file-attributes`="None"
)

file_default_perms <- list(
    `x-ms-file-permission`="inherit",
    `x-ms-file-creation-time`="now",
    `x-ms-file-last-write-time`="now",
    `x-ms-file-attributes`="None"
)

file_update_perms <- list(
    `x-ms-file-permission`="inherit",
    `x-ms-file-creation-time`="preserve",
    `x-ms-file-last-write-time`="preserve",
    `x-ms-file-attributes`="None"
)
