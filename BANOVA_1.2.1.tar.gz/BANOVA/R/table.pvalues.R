table.pvalues <-
function(x){
  x$pvalue.table
}
