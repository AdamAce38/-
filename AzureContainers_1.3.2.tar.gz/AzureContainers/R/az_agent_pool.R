# stub class, may be expanded later
az_agent_pool <- R6::R6Class("az_agent_pool", inherit=AzureRMR::az_resource)
