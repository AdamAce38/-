library(testthat)
library(AzureQstor)

test_check("AzureQstor")
