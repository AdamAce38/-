# library(ARGOS)
# devtools::load_all(".")
# devtools::test()
# devtools::test("tests/testthat")
library(testthat)
library(ARGOS)  # Your package
test_check("ARGOS")  # Your package name
