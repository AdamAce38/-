#' @useDynLib Apollonius, .registration=TRUE
#' @importFrom Rcpp evalCpp
NULL
