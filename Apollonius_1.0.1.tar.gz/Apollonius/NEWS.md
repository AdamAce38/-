# Apollonius 1.0.1

The package does no longer depends on the package 'randomcoloR', but it now 
depends on the packages 'colorsGen' and 'Polychrome'.


# Apollonius 1.0.0

First release.
