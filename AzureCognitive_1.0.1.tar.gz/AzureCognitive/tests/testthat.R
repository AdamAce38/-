library(testthat)
library(AzureCognitive)

test_check("AzureCognitive")
