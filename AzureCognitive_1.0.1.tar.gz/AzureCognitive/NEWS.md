# AzureCognitive 1.0.1

- Fix token authentication method for Text Translation (reported by @quickcoffee).
- Change maintainer email address.

# AzureCognitive 1.0.0

- Initial release to CRAN.
