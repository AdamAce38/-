# AvInertia 0.0.2

* Updated to reference the now published paper: Harvey, C., Baliga, V.B., Wong, J.C.M., Altshuler D.L., and Inman, D.J. Birds can transition between stable and unstable states via wing morphing. Nature 603, 648–653 (2022). https://doi.org/10.1038/s41586-022-04477-8

# AvInertia 0.0.1

* Created news file to keep track of updates once published to CRAN
