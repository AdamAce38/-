library(testthat)
library(ActivePathways)

test_check("ActivePathways")
