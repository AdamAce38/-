library(testthat)
library(AzureVM)

test_check("AzureVM")
