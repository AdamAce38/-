# This file contains no code: the bundle formerly known as BACCO is
# now a 'virtual' package which requires the constituent packages:
# emulator, calibrator, and approximator.
