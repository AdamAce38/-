#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom magrittr %>%
#' @importFrom Rcpp sourceCpp
#' @useDynLib APackOfTheClones, .registration = TRUE
## usethis namespace: end
NULL
