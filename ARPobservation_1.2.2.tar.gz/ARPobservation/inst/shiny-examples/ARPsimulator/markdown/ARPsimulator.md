### The Alternating Renewal Process Simulator

Version 0.2

Designed and built by James E. Pustejovsky.

* pusto@austin.utexas.edu
* https://www.jepusto.com/

[Source code available on Github](https://github.com/jepusto/ARPobservation/tree/master/inst/shiny-examples/ARPsimulator)

_Your comments, suggestions, and feedback are welcome._
